# Renko TeX-first Jekyll Site

这是一个适合数学笔记的 GitHub Pages / Jekyll 模板。核心原则是：

- `.tex` 是你的源文件；
- `.pdf` 是对外发布版本；
- 网站页面只负责自动索引，不需要为每篇笔记写 Markdown。

## 你以后需要做什么

把同名的 `.pdf` 和 `.tex` 放进对应分类目录，然后 push 即可。

例如：

```text
assets/notes/algebraic-geometry/sheaves.pdf
assets/notes/algebraic-geometry/sheaves.tex
```

网站会自动显示为：

```text
Sheaves
PDF | TeX
```

再例如：

```text
assets/notes/representation-theory/orthogonality-relations.pdf
assets/notes/representation-theory/orthogonality-relations.tex
```

网站会自动显示为：

```text
Orthogonality Relations
PDF | TeX
```

文件名建议使用小写英文和连字符：

```text
characters.pdf
characters.tex
induced-representations.pdf
induced-representations.tex
```

## 已有分类目录

```text
assets/notes/algebra/
assets/notes/commutative-algebra/
assets/notes/algebraic-geometry/
assets/notes/representation-theory/
assets/notes/homological-algebra/
assets/notes/number-theory/
assets/notes/analysis/
assets/notes/misc/
```

## 如何部署到 GitHub Pages

1. 把这个文件夹内容放进你的 GitHub repo。
2. 进入 repo 的 Settings → Pages。
3. Build and deployment 选择 **GitHub Actions**。
4. push 到 `main` 或 `master` 分支。

GitHub Actions 会自动：

1. 扫描 `assets/notes/` 下的 `.pdf` 和 `.tex`；
2. 生成 `_data/notes.json`；
3. 构建 Jekyll 网站；
4. 部署到 GitHub Pages。

## 本地预览

安装 Ruby 和 Bundler 后运行：

```bash
bundle install
bash scripts/preview.sh
```

然后打开：

```text
http://localhost:4000
```

## 如果只想发布 PDF

可以只上传：

```text
assets/notes/algebraic-geometry/sheaves.pdf
```

网站会只显示 PDF 链接。

## 如果也想公开 TeX 源文件

上传同名 `.tex`：

```text
assets/notes/algebraic-geometry/sheaves.tex
```

网站会显示 TeX 链接。

## 如何新增分类

假设你想新增 `category-theory`：

1. 新建目录：

```text
assets/notes/category-theory/
```

2. 在 `_data/categories.yml` 里加入：

```yml
- key: category-theory
  title: Category Theory
  zh: 范畴论
  url: /notes/category-theory/
```

3. 在 `_pages/` 下新增：

```text
_pages/category-theory.md
```

内容：

```markdown
---
layout: category
title: Category Theory
category: category-theory
permalink: /notes/category-theory/
---

Category theory notes.
```

之后就可以上传：

```text
assets/notes/category-theory/yoneda-lemma.pdf
assets/notes/category-theory/yoneda-lemma.tex
```
